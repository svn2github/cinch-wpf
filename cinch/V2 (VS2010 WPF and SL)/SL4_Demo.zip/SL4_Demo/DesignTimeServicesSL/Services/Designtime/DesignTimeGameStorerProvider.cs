﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel.Composition;
using System.Collections.Generic;

using MEFedMVVM.ViewModelLocator;
using CinchV2DemoSL;

namespace DesignTimeServicesSL
{

    /// <summary>
    /// Runtime Data service used to store/retrieve game data
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportService(ServiceType.DesignTime, typeof(IGameStorerProvider))]
    public class DesignTimeGameStorerProvider : IGameStorerProvider
    {
        #region IGameStorerProvider Members

        public void StoreGameResults(string winnerName, string completeGameText)
        {
            //do nothing
        }

        public void WriteUserNameToFile(string username)
        {
            //do nothing
        }

        public string ReadUserNameFromFile()
        {
            return "Sacha";
        }

        public void FetchGameResults(Action<List<Tuple<string, string>>> callback)
        {
            List<Tuple<string, string>> results = new List<Tuple<string, string>>();
            results.Add(new Tuple<string,string>("Sacha won","O:X:X:O:O:X:X:O:O:"));
            results.Add(new Tuple<string,string>("Computer won","O:O:O:X:X:X:X:O:O:"));
            results.Add(new Tuple<string,string>("Sacha won","O:X:X:O:O:X:X:O:O:"));
            callback(results);
        }

        #endregion
    }
}
