﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Data service used to store/retrieve game data
    /// </summary>
    public interface IGameStorerProvider
    {
        void StoreGameResults(string winnerName, String completeGameText);
        void WriteUserNameToFile(string username);
        string ReadUserNameFromFile();
        void FetchGameResults(Action<List<Tuple<string, string>>> callback);
    }
}
