﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel.Composition;
using System.Collections.Generic;
using MEFedMVVM.ViewModelLocator;
using Cinch;

namespace CinchV2DemoSL
{

    /// <summary>
    /// Runtime Data service used to store/retrieve game data
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportService(ServiceType.Runtime, typeof(IGameStorerProvider))]
    public class RunTimeGameStorerProvider : IGameStorerProvider
    {

        #region Data
        private BackgroundTaskManager<object,List<Tuple<string, string>>> bgWorker = 
            new BackgroundTaskManager<object, List<Tuple<string, string>>>();
        #endregion

        #region IGameStorerProvider Members

        public void StoreGameResults(string winnerName, string completeGameText)
        {
            IsolatedStorageHelper.StoreGameResults(winnerName, completeGameText);
        }

        public void WriteUserNameToFile(string username)
        {
            IsolatedStorageHelper.WriteUserNameToFile(username);
        }

        public string ReadUserNameFromFile()
        {
            return IsolatedStorageHelper.ReadUserNameFromFile();
        }

        public void FetchGameResults(Action<List<Tuple<string, string>>> callback)
        {
            bgWorker.TaskFunc = (argument) =>
            {
                return IsolatedStorageHelper.FetchGameResults();
            };

            bgWorker.CompletionAction = (result) =>
            {
                callback(result);
            };

            bgWorker.RunBackgroundTask();

            
        }
        #endregion

        #region Public Properties

        /// <summary>
        /// To allow this class to be unit tested stand alone
        /// See CinchV1 articles about Unit Testing for this
        /// Or comments in Cinch BackgroundTaskManager<T> class
        /// </summary>
        public BackgroundTaskManager<object, List<Tuple<string, string>>> BgWorker
        {
            get { return bgWorker; }
        }

        #endregion
    }
}
