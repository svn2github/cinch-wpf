﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

using Cinch;
using MEFedMVVM.Common;
using MEFedMVVM.ViewModelLocator;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Game statistics ViewModel
    /// Demonstrates CinchV2 ChildWindowService, MessageBoxService and MeffedMVVM
    /// service injection, and querying the Meffed MEF container directly
    /// </summary>
    public class GameStatViewModel : ViewModelBase
    {
        #region Data
        private string winnerName;
        private string gameText;
        private ICommand viewGameCommand;
        private IChildWindowService ChildWindowService { get; set; }
        private IMessageBoxService MessageBoxService { get; set; }
        #endregion

        #region Ctor
        public GameStatViewModel(string winnerName, string gameText)
        {
            this.WinnerName = winnerName;
            this.GameText = gameText;

            if (!Designer.IsInDesignMode)
            {
                ChildWindowService = 
                    ViewModelRepository.Instance.Resolver.Container.GetExport<IChildWindowService>().Value;
               
                MessageBoxService = 
                    ViewModelRepository.Instance.Resolver.Container.GetExport<IMessageBoxService>().Value;
            }

            ViewGameCommand = new SimpleCommand<Object, Object>(ExecuteViewGameCommand);

        }
        #endregion

        #region Public Methods/Properties
        public SimpleCommand<Object, Object> ViewGameCommand { get; private set; }

        /// <summary>
        /// WinnerName
        /// </summary>
        static PropertyChangedEventArgs winnerNameChangeArgs =
            ObservableHelper.CreateArgs<GameStatViewModel>(x => x.WinnerName);

        public string WinnerName
        {
            get { return winnerName; }
            set
            {
                winnerName = value;
                NotifyPropertyChanged(winnerNameChangeArgs);
            }
        }


        /// <summary>
        /// GameText
        /// </summary>
        static PropertyChangedEventArgs gameTextChangeArgs =
            ObservableHelper.CreateArgs<GameStatViewModel>(x => x.GameText);

        public string GameText
        {
            get { return gameText; }
            set
            {
                gameText = value;
                NotifyPropertyChanged(gameTextChangeArgs);
            }
        }
        #endregion

        #region Commands
        #region ViewGameCommand


        private void ExecuteViewGameCommand(object o)
        {
            bool? dialogResult = null;
            ChildWindowService.Show("PlayedGameChildWindow", 
                new PlayedGameViewModel(GameText), (s, e) =>
            {
                dialogResult = e.Result;
                string result = dialogResult.HasValue && dialogResult.Value ? "ok" : "Cancel";
                //MessageBoxService.ShowInformation("You clicked " + result);
                //you can do what you like with dialogResult
            });

        }
        #endregion
        #endregion
    }
}
