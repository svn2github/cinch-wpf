﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using System.ComponentModel.Composition;
using System.ComponentModel;
using System.Linq;

using Cinch;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Simple Played game ViewModel
    /// </summary>
    public class PlayedGameViewModel : ViewModelBase
    {
        #region Data
        private List<GameCellViewModel> gameCells = new List<GameCellViewModel>();
        #endregion

        #region Ctor
        public PlayedGameViewModel(string playedGameString)
        {

            string[] states = playedGameString.Split(":".ToCharArray());
            int count = 0;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    GameCellViewModel cell = new GameCellViewModel(i, j);
                    cell.CellText = states[count];
                    cell.IsCellEnabled = false;
                    count++;
                    gameCells.Add(cell);
                }
            }
            NotifyPropertyChanged(gameCellsChangeArgs);
        }
        #endregion

        #region Public Methods/Properties
        /// <summary>
        /// GameStats
        /// </summary>
        static PropertyChangedEventArgs gameCellsChangeArgs =
            ObservableHelper.CreateArgs<PlayedGameViewModel>(x => x.GameCells);


        public IEnumerable<GameCellViewModel> GameCells
        {
            get { return (from x in gameCells select x); }
        }
        #endregion

    }
}
