﻿using System;
using Cinch;
using System.ComponentModel;
using System.Windows.Input;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Simple GameCell ViewModel, represents one tile in Game
    /// Demonstrates Cinch Commands
    /// </summary>
    public class GameCellViewModel : ViewModelBase
    {
        #region Data
        private bool isCellEnabled = true;
        private string cellText;
        private ICommand playCommand;
        private int row = 0;
        private int col = 0;
        #endregion

        #region Ctor
        public GameCellViewModel(int row, int col)
        {
            this.row = row;
            this.col = col;
            PlayCommand = new SimpleCommand<Object, Object>(CanExecutePlayCommand, ExecutePlayCommand);
        }
        #endregion

        #region Public Methods/Properties
        public static readonly string PlayersText = "O";
        
        public static readonly string ComputersText = "X";

        public event Action<GameCellViewModel> CellClicked;
        
        
        public int Row
        {
            get { return row; }
        }

        public int Col
        {
            get { return col; }
        }


        /// <summary>
        /// IsCellEnabled
        /// </summary>
        static PropertyChangedEventArgs isCellEnabledChangeArgs =
            ObservableHelper.CreateArgs<GameCellViewModel>(x => x.IsCellEnabled);

        public bool IsCellEnabled
        {
            get { return isCellEnabled; }
            set
            {
                isCellEnabled = value;
                NotifyPropertyChanged(isCellEnabledChangeArgs);
            }
        }


        /// <summary>
        /// CellText
        /// </summary>
        static PropertyChangedEventArgs cellTextChangeArgs =
            ObservableHelper.CreateArgs<GameCellViewModel>(x => x.CellText);

        public string CellText
        {
            get { return cellText; }
            set
            {
                cellText = value;
                NotifyPropertyChanged(cellTextChangeArgs);
            }
        }

        public SimpleCommand<Object, Object> PlayCommand { get; private set; }
        #endregion

        #region Commands
        #region PayNowCommand

        private bool CanExecutePlayCommand(object args)
        {
            return this.IsCellEnabled;
        }

        private void ExecutePlayCommand(object args)
        {
            IsCellEnabled = false;

            if (GameViewModel.IsPlayersTurn)
            {
                this.CellText = GameCellViewModel.PlayersText;
            }
            else
            {
                this.CellText = GameCellViewModel.ComputersText;
            }

            if (args == null)
            {
                if (CellClicked != null)
                    CellClicked(this);
            }
        }
        #endregion
        #endregion
    }
}
