﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using System.ComponentModel.Composition;
using System.ComponentModel;
using System.Linq;

using Cinch;
using MEFedMVVM.ViewModelLocator;

namespace CinchV2DemoSL
{

    /// <summary>
    /// Game ViewModel
    /// Demonstrates CinchV2 ChildWindowService/MessageBoxService/IVSM service/IViewAwareStatus service/
    /// Mediator and MeffedMVVM service injection, along with a utility service that is used at both design/runtime
    /// </summary>
    [ExportViewModel("GameViewModel")]
    public class GameViewModel : ViewModelBase
    {
        #region Data
        private List<GameCellViewModel> gameCells = new List<GameCellViewModel>();
        private List<GameCellViewModel> remainingCells = new List<GameCellViewModel>();
        private Random rand = new Random();
        private ICommand restartCommand;
        private bool haveWinner = false;
        private bool isCompleted = false;
        private string winnerName;
        //services
        private IMessageBoxService messageBoxService;
        private IVSM visualStateManagerService;
        private IViewAwareStatus viewAwareStatusService;
        private IGameStorerProvider gameStorerProvider;
        #endregion

        #region Ctor
        [ImportingConstructor]
        public GameViewModel(            
            IMessageBoxService messageBoxService,
            IVSM visualStateManagerService,
            IGameStorerProvider gameStorerProvider)
        {

            this.messageBoxService = messageBoxService;
            this.visualStateManagerService = visualStateManagerService;
            this.gameStorerProvider = gameStorerProvider;


            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    GameCellViewModel cell = new GameCellViewModel(i, j);
                    cell.CellClicked += CellClicked;
                    gameCells.Add(cell);
                    remainingCells.Add(cell);
                }
            }

            RestartCommand = new SimpleCommand<Object,Object>(ExecuteRestartCommand);

            Mediator.Instance.Register(this);
        }
        #endregion

        #region Private Methods
        private void CellClicked(GameCellViewModel clickedCell)
        {
            remainingCells.Remove(clickedCell);
            IsCompleted = remainingCells.Count == 0;
            CheckForWinner(clickedCell);
            CheckForCompleted();

            if (!IsCompleted && !HaveWinner)
                ComputersTurn();
        }

        private void CheckForCompleted()
        {
            if (IsCompleted)
            {
                StoreGameState();
                visualStateManagerService.GoToState("WinOrCompletedState");
            }
        }

        private void CheckForWinner(GameCellViewModel currentCell)
        {

            //row
            int rowCount = (from c in gameCells
                            where c.Row == currentCell.Row &&
                            c.CellText == currentCell.CellText
                            select c).Count();

            //col
            int colCount = (from c in gameCells
                            where c.Col == currentCell.Col &&
                            c.CellText == currentCell.CellText
                            select c).Count();

            //diag
            int nwDiagsCount = GetDiagCells(-1, -1, currentCell).Where(c => c.CellText == currentCell.CellText).Count();
            int swDiagsCount = GetDiagCells(1, -1, currentCell).Where(c => c.CellText == currentCell.CellText).Count();
            int neDiagsCount = GetDiagCells(-1, 1, currentCell).Where(c => c.CellText == currentCell.CellText).Count();
            int seDiagsCount = GetDiagCells(1, 1, currentCell).Where(c => c.CellText == currentCell.CellText).Count();

            if (rowCount == 3 || colCount == 3)
            {
                SetWinState(currentCell.CellText);
                return;
            }

            //check north west to south east
            if (nwDiagsCount == 3 || seDiagsCount == 3)
            {
                SetWinState(currentCell.CellText);
                return;
            }

            //check south west to north east
            if (swDiagsCount == 3 || neDiagsCount == 3)
            {
                SetWinState(currentCell.CellText);
                return;
            }

        }


        private void SetWinState(string winnerText)
        {
            HaveWinner = true;
            WinnerName = winnerText + " Wins";
            DisableRemainingCells();
            StoreGameState();
            visualStateManagerService.GoToState("WinOrCompletedState");
        }



        private void StoreGameState()
        {

            string actualWinnerName = WinnerName.StartsWith(GameCellViewModel.PlayersText) ?
                IsolatedStorageHelper.ReadUserNameFromFile() + " won" : "Computer won";
            string winner = HaveWinner ? actualWinnerName : "no winner";

            string gameText = "";
            foreach (GameCellViewModel cell in gameCells)
            {
                gameText += cell.CellText + ":";
            }
            gameText.TrimEnd(":".ToCharArray());

            gameStorerProvider.StoreGameResults(actualWinnerName, gameText);

            Mediator.Instance.NotifyColleagues<bool>("RefreshGameStats", true);
        }

        private void DisableRemainingCells()
        {
            foreach (GameCellViewModel cell in remainingCells)
            {
                cell.IsCellEnabled = false;
            }
        }


        private IEnumerable<GameCellViewModel> GetDiagCells(int rOffset, int cOffset, GameCellViewModel currentCell)
        {

            int row = currentCell.Row;
            int col = currentCell.Col;

            while (StillOnBoard(row, col))
            {
                yield return (from c in gameCells
                              where c.Row == row && c.Col == col
                              select c).Single();
                row = row + rOffset;
                col = col + cOffset;

            }
        }

        private bool StillOnBoard(int row, int col)
        {
            return (row >= 0 && row <= 2 && col >= 0 && col <= 2);
        }


        private void ComputersTurn()
        {
            int newIdx = (int)rand.NextDouble() * remainingCells.Count;
            GameCellViewModel cell = remainingCells[newIdx];
            remainingCells.RemoveAt(newIdx);
            GameViewModel.IsPlayersTurn = false;
            cell.PlayCommand.Execute(true);
            CheckForWinner(cell);
            IsCompleted = remainingCells.Count == 0;
            CheckForCompleted();
            GameViewModel.IsPlayersTurn = true;

        }
#endregion

        #region Public Methods/Properties
        public static bool IsPlayersTurn = true;

        public IList<GameCellViewModel> GameCells
        {
            get { return gameCells; }
        }

        public SimpleCommand<Object, Object> RestartCommand { get; private set; }


        /// <summary>
        /// HaveWinner
        /// </summary>
        static PropertyChangedEventArgs haveWinnerChangeArgs =
            ObservableHelper.CreateArgs<GameViewModel>(x => x.HaveWinner);

        public bool HaveWinner
        {
            get { return haveWinner; }
            set
            {
                haveWinner = value;
                NotifyPropertyChanged(haveWinnerChangeArgs);
            }
        }


        /// <summary>
        /// IsCompleted
        /// </summary>
        static PropertyChangedEventArgs isCompletedChangeArgs =
            ObservableHelper.CreateArgs<GameViewModel>(x => x.IsCompleted);

        public bool IsCompleted
        {
            get { return isCompleted; }
            set
            {
                isCompleted = value;
                NotifyPropertyChanged(isCompletedChangeArgs);
            }
        }


        /// <summary>
        /// IsCompleted
        /// </summary>
        static PropertyChangedEventArgs winnerNameChangeArgs =
            ObservableHelper.CreateArgs<GameViewModel>(x => x.WinnerName);

        public string WinnerName
        {
            get { return winnerName; }
            set
            {
                winnerName = value;
                NotifyPropertyChanged(winnerNameChangeArgs);
            }
        }
        #endregion

        #region Commands
        #region RestartCommand


        private void ExecuteRestartCommand(object o)
        {
            remainingCells.Clear();
            foreach (GameCellViewModel cell in GameCells)
            {
                cell.IsCellEnabled = true;
                cell.CellText = String.Empty;
                remainingCells.Add(cell);
            }
            HaveWinner = false;
            IsCompleted = false;
            WinnerName = string.Empty;
            GameViewModel.IsPlayersTurn = true;
            visualStateManagerService.GoToState("RestartedState");

        }
        #endregion
        #endregion

        #region Overrides
        protected override void OnDispose()
        {
            base.OnDispose();
            Mediator.Instance.Unregister(this);
        }
        #endregion

    }
}
