﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel.Composition;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;

using Cinch;
using MEFedMVVM.ViewModelLocator;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Game Stat List ViewModel
    /// Demonstrates CinchV2 IDataErrorInfo support/DataWrappers/IVSM service
    /// MeffedMVVM service injection
    /// </summary>
    [ExportViewModel("UserEntryViewModel")]
    public class UserEntryViewModel : ValidatingViewModelBase
    {

        #region Data
        private DataWrapper<String> userName;
        private IEnumerable<DataWrapperBase> cachedListOfDataWrappers;
        private static SimpleRule userNameRule;

        private IMessageBoxService messageBoxService;
        private IViewAwareStatus viewAwareStatusService;
        private IChildWindowService childWidowService;
        private IGameStorerProvider gameStorerProvider;
        private IVSM visualStateManagerService;
    

        #endregion

        #region Ctor
        [ImportingConstructor]
        public UserEntryViewModel(
            IMessageBoxService messageBoxService,
            IViewAwareStatus viewAwareStatusService,
            IChildWindowService childWidowService,
            IGameStorerProvider gameStorerProvider,
            IVSM visualStateManagerService)
        {

            this.messageBoxService = messageBoxService;
            this.viewAwareStatusService = viewAwareStatusService;
            this.childWidowService = childWidowService;
            this.gameStorerProvider = gameStorerProvider;
            this.visualStateManagerService = visualStateManagerService;

            //Commands
            SaveUserNameCommand = new SimpleCommand<Object, Object>(ExecuteSaveUserNameCommand);

            #region Create DataWrappers

            UserName = new DataWrapper<String>(this, userNameChangeArgs);
            UserName.IsEditable = true;

            //fetch list of all DataWrappers, so they can be used again later without the
            //need for reflection
            cachedListOfDataWrappers =
                DataWrapperHelper.GetWrapperProperties<UserEntryViewModel>(this);
            #endregion

            #region Create Validation Rules

            userName.AddRule(userNameRule);
            #endregion
 
        }

       

        static UserEntryViewModel()
        {

            userNameRule = new SimpleRule("DataValue", "UserName can not be empty",
                    (Object domainObject) =>
                    {
                        DataWrapper<String> obj = (DataWrapper<String>)domainObject;
                        return String.IsNullOrEmpty(obj.DataValue);
                    });
        }
        #endregion

        #region Public Properties
        

        //commands
        public SimpleCommand<Object, Object> SaveUserNameCommand { get; private set; }

        /// <summary>
        /// UserName
        /// </summary>
        static PropertyChangedEventArgs userNameChangeArgs =
            ObservableHelper.CreateArgs<UserEntryViewModel>(x => x.UserName);

        public DataWrapper<String> UserName
        {
            get { return userName; }
            private set
            {
                userName = value;
                NotifyPropertyChanged(userNameChangeArgs);
            }
        }

        #endregion

        #region Commands

        #region SaveUserNameCommand

        private void ExecuteSaveUserNameCommand(Object args)
        {
            if (IsValid)
            {
                visualStateManagerService.GoToState("ValidState");
                gameStorerProvider.WriteUserNameToFile(UserName.DataValue);
                messageBoxService.ShowError("Successfully saved username, flip to play a game!");
            }
            else
            {
                visualStateManagerService.GoToState("InValidState");
                messageBoxService.ShowError("The UserName entered is invalid it must contain a value");
            }
        }

        #endregion
        #endregion

        #region Overrides

        /// <summary>
        /// Is the ViewModel Valid
        /// </summary>

        static PropertyChangedEventArgs isValidChangeArgs =
            ObservableHelper.CreateArgs<UserEntryViewModel>(x => x.IsValid);

        public override bool IsValid
        {
            get
            {
                //return base.IsValid and use DataWrapperHelper, if you are
                //using DataWrappers
                return base.IsValid &&
                    DataWrapperHelper.AllValid(cachedListOfDataWrappers);
            }

        }
        #endregion

    }
}
