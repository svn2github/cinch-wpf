﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using System.ComponentModel.Composition;
using System.ComponentModel;
using System.Linq;
using System.Collections.ObjectModel;

using Cinch;
using MEFedMVVM.ViewModelLocator;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Game Stat List ViewModel
    /// Demonstrates CinchV2 CIViewAwareStatus service/Mediator
    /// MeffedMVVM service injection, along with a utility service that is used at both design/runtime
    /// </summary>
    [ExportViewModel("ListGameStatViewModel")]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class ListGameStatViewModel : ViewModelBase
    {
        #region Data
        private ObservableCollection<GameStatViewModel> gameStats=new ObservableCollection<GameStatViewModel>();
        private IGameStorerProvider gameStorerProvider;
        private IViewAwareStatus viewAwareStatusService;
        #endregion

        #region Ctor
        [ImportingConstructor]
        public ListGameStatViewModel(
            IGameStorerProvider gameStorerProvider,
            IViewAwareStatus viewAwareStatusService)
        {
            this.gameStorerProvider = gameStorerProvider;
            this.viewAwareStatusService = viewAwareStatusService;
            this.viewAwareStatusService.ViewLoaded += viewAwareStatusService_ViewLoaded;
            Mediator.Instance.Register(this);
        }
        #endregion

        #region Mediator Message Sinks
        [MediatorMessageSinkAttribute("RefreshGameStats")]
        public void RefreshGameStatsMessageSink(bool dummy)
        {
            FetchData();
        }
        #endregion

        #region Public Methods/Properties
        /// <summary>
        /// GameStats
        /// </summary>
        static PropertyChangedEventArgs gameStatsChangeArgs =
            ObservableHelper.CreateArgs<ListGameStatViewModel>(x => x.GameStats);

        public ObservableCollection<GameStatViewModel> GameStats
        {
            get { return gameStats; }
            set
            {
                gameStats = value;
                NotifyPropertyChanged(gameStatsChangeArgs);
            }
        }
        #endregion

        #region Private Methods
        private void viewAwareStatusService_ViewLoaded()
        {
            FetchData();
        }

        private void FetchData()
        {
            gameStorerProvider.FetchGameResults(LoadImagesFromRetrievedData);
        }


        private void LoadImagesFromRetrievedData(List<Tuple<string, string>> data)
        {
            ObservableCollection<GameStatViewModel> newStats = new ObservableCollection<GameStatViewModel>();
            foreach (Tuple<String, String> result in data)
            {
                newStats.Add(new GameStatViewModel(result.Item1, result.Item2));
            }
            GameStats = newStats;
        }

        #endregion

        #region Overrides
        protected override void OnDispose()
        {
            base.OnDispose();
            Mediator.Instance.Unregister(this);
        }
        #endregion

    }
}
