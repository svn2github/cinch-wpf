﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using System.Linq;
using Cinch;

namespace CinchV2DemoSL
{
    /// <summary>
    /// Simple IsolatedStorage file helper
    /// </summary>
    public class IsolatedStorageHelper
    {
        #region Public Methods
        public static void ClearCinchSLDemoFilesStorageContents()
        {
            using (IsolatedStorageFile isoStore =
                IsolatedStorageFile.GetUserStoreForApplication())
            {
                //delete UserEntryFile.txt
                if (isoStore.FileExists("UserEntryFile.txt"))
                    isoStore.DeleteFile("UserEntryFile.txt");

                //delete UserEntryFile.txt
                if (isoStore.FileExists("GameStats.txt"))
                    isoStore.DeleteFile("GameStats.txt");
            }
        }



        public static void WriteUserNameToFile(string username)
        {

            using (IsolatedStorageFile isoStore =
                IsolatedStorageFile.GetUserStoreForApplication())
            {

                //delete UserEntryFile.txt
                if (isoStore.FileExists("UserEntryFile.txt"))
                    isoStore.DeleteFile("UserEntryFile.txt");

                using (StreamWriter writer = new StreamWriter(
                    new IsolatedStorageFileStream("UserEntryFile.txt", FileMode.CreateNew, isoStore)))
                {
                    writer.WriteLine(String.Format("UserName:{0}",username));
                }
            }
        }


        public static string ReadUserNameFromFile()
        {
            string userName = string.Empty;
            using (IsolatedStorageFile isoStore =
                IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (StreamReader reader = new StreamReader(
                    new IsolatedStorageFileStream("UserEntryFile.txt", FileMode.Open, isoStore)))
                {
                    string fullLine = reader.ReadLine();
                    string[] parts = fullLine.Split(":".ToCharArray());
                    userName = parts[1];
                }
            }

            return userName;
        }



        public static void StoreGameResults(string winnerName, string completeGameText)
        {

            using (IsolatedStorageFile isoStore =
                IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (StreamWriter writer = new StreamWriter(
                    new IsolatedStorageFileStream("GameStats.txt", FileMode.Append, isoStore)))
                {
                    writer.WriteLine(String.Format("UserName:{0}/{1}", winnerName, completeGameText));
                }
            }
        }


        public static List<Tuple<String, String>> FetchGameResults()
        {
            List<Tuple<String, String>> results = new List<Tuple<string, string>>();

            using (IsolatedStorageFile isoStore =
                IsolatedStorageFile.GetUserStoreForApplication())
            {

                using (StreamReader reader = new StreamReader(
                    new IsolatedStorageFileStream("GameStats.txt", FileMode.Open, isoStore)))
                {
                    string fullLine = reader.ReadLine();
                    do
                    {

                        string[] parts = fullLine.Split("/".ToCharArray());
                        string[] namePart = parts[0].Split(":".ToCharArray());
                        results.Add(new Tuple<string, string>(namePart[1], parts[1]));
                        fullLine = reader.ReadLine();
                    } while (fullLine != null);


                }
            }

            return results;
        }
        #endregion
    }
}
