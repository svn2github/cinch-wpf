﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Diagnostics;
using System.ComponentModel;
using System.Collections.Generic;

using MEFedMVVM.ViewModelLocator;
using Cinch;
using MEFedMVVM.Common;

namespace CinchV2DemoWPF
{
    /// <summary>
    /// This ViewModel demonstrates how to use WorkSpaces and Menus. You will
    /// need to look in the MainWindow.xaml and also the AppStyles.xaml ResourceDictionary
    /// to see how the Styles are used to tie up with this ViewModel
    /// </summary>
    [ExportViewModel("MainWindowViewModel")]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class MainWindowViewModel : ViewModelBase
    {
        #region Data
        private bool showContextMenu = false;
        private IViewAwareStatus viewAwareStatusService;
        #endregion

        #region Ctor
        [ImportingConstructor]
        public MainWindowViewModel(IViewAwareStatus viewAwareStatusService)
        {
            this.viewAwareStatusService = viewAwareStatusService;
            this.viewAwareStatusService.ViewLoaded += ViewAwareStatusService_ViewLoaded;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Creates and returns the menu items
        /// </summary>
        private List<CinchMenuItem> CreateMenus()
        {

            List<CinchMenuItem> menu = new List<CinchMenuItem>();

            CinchMenuItem menuActions = new CinchMenuItem("Actions");
            menu.Add(menuActions);

            CinchMenuItem menuAbout = new CinchMenuItem("About CinchV2");
            menuAbout.Command = new SimpleCommand<object, object>((x) =>
            {
                WorkspaceData workspace2 = new WorkspaceData(@"/CinchV2DemoWPF;component/Images/About.png",
                    "AboutView", null, "About Cinch V2", true);
                Views.Add(workspace2);
                ShowContextMenu = false;
            });
            menuActions.Children.Add(menuAbout);
            return menu;
        }

        private void ViewAwareStatusService_ViewLoaded()
        {

            if (Designer.IsInDesignMode)
                return;

            String imagePath = ConfigurationManager.AppSettings["YourImagePath"].ToString();


            WorkspaceData workspace1 = new WorkspaceData(@"/CinchV2DemoWPF;component/Images/imageIcon.png",
                "ImageLoaderView", imagePath, "Image View", false);

            WorkspaceData workspace2 = new WorkspaceData(@"/CinchV2DemoWPF;component/Images/About.png",
                 "AboutView", null, "About Cinch V2", true);



            Views.Add(workspace1);
            Views.Add(workspace2);
            SetActiveWorkspace(workspace1);
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// Returns the bindbable Main Window options
        /// </summary>
        public List<CinchMenuItem> MainWindowOptions
        {
            get
            {
                return CreateMenus();
            }
        }


        /// <summary>
        /// ShowContextMenu
        /// </summary>
        static PropertyChangedEventArgs showContextMenuArgs =
            ObservableHelper.CreateArgs<MainWindowViewModel>(x => x.ShowContextMenu);

        public bool ShowContextMenu
        {
            get { return showContextMenu; }
            private set
            {
                showContextMenu = value;
                NotifyPropertyChanged(showContextMenuArgs);
            }
        }

        //Service properties
        public IViewAwareStatus ViewAwareStatusService { get; private set; }

        #endregion

    }

}
